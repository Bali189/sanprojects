import os
import time
import datetime

def IsDone(devnumbers):
	command = ("./HiCommandCLI GetZeroPageReclaimStatus model=HM800M serialnum=410246 devnums=%s > output.txt" % ",".join(devnumbers))
	os.system(command);
	done = 1
	with open("output.txt", "r") as outfid:
		for line in outfid:
			if ("An instance of LogicalUnit" in line.strip()):
				done = 0
				break
	return done


def Finish(devnumbers):
	interval = 60 * 30
	command = ("./HiCommandCLI RunZeroPageReclaim serialnum=410246 model=HM800M devnums=%s" % ",".join(devnumbers))
	os.system(command);
	while (IsDone(devnumbers) == 0):
		time.sleep(interval);

def Querry(timestamp):
	command = ("./HiCommandCLI GetStorageArray model=HM800M serialnum=410246 subtarget=Pool | tee status.txt status_%s.txt" % timestamp)
	os.system(command);
	return None
	

def GetSpecs(outfid):
	rparams = ["name", "poolID", "capacityInKB", "usageRate", "basicUsableCapacityUsed"]
	wparams = ["name", "poolID", "capacityInTB", "usageRate", "basicUsableCapacityUsed"]
	npool = 0
	current = -1
	skip = 1
	with open("status.txt", "r") as statfid:
		for line in statfid:
			relevant = line.strip()
			if ("Pool elements:" in relevant):
				npool = int(relevant.split(" ")[2])
				pool = [{prop:("%d" % dev) for prop in rparams} for dev in range(npool)]
				skip = 0

			if (skip == 0):
				if ("An instance of Pool" in relevant):
					current = current + 1

				for prop in rparams:
					if (prop in relevant):
						if ((prop == "capacityInKB") or (prop == "basicUsableCapacityUsed")):
							pool[current][prop] = ("%.3f" % (int(relevant.split("=")[1].replace(",", ""))/float(1024 * 1024 * 1024)))
						else:
							pool[current][prop] = relevant.split("=")[1].replace(",", "")

	# Write the specs on to a file
	for pi in range(len(rparams)):
		outfid.write("%s       " % wparams[pi])
	outfid.write("\n")
	for sp in range(npool):
		for prop in rparams:
			outfid.write("%s       " % pool[sp][prop])
		outfid.write("\n")
	return None

if __name__ == '__main__':
	datetime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
	start = time.time()
	devnums = []
	email = "storage@adobe.com"
	with open("numbers.txt", "r") as numfid:
		for line in numfid:
			if ("@" in line):
				email = line.strip()
			else:
				devnums.append(line.strip())
	Querry("before")
	name = "noname"
	serial = "nan"
	with open("status.txt", "r") as statfid:
		for line in statfid:
			relevant = line.strip()
			if ("name=" in relevant):
				if (name == "noname"):
					name = relevant.split("=")[1].strip()
			if ("serialNumber=" in relevant):
				serial = relevant.split("=")[1].strip()

	with open("report.txt", "w") as repfid:
		repfid.write("Status querry made on %s.\n\n" % datetime)
		repfid.write("Name of the Storage array: %s\n" % name)
		repfid.write("Serial number: %s\n\n" % serial)
		repfid.write("LUNs processed\n%s\n\n." % ", ".join(devnums))
		repfid.write("Status before querry\n\n")
		GetSpecs(repfid)
		repfid.write("\n\n")
		Finish(devnums)
		Querry("after")
		repfid.write("Status after querry\n\n")
		GetSpecs(repfid)
		repfid.write("\n\n")
		runtime = time.time() - start
		repfid.write("Total status querry time : %d hours %d minutes and %d seconds.\n\n" % (runtime/3600, (runtime % 3600)/60, runtime % 60))
	
	# send the contents of report.txt as email
	command = ("mail -s '"'Zero page reclaimed'"' %s < report.txt" % email)
	os.system(command)

