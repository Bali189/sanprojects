# SANProjects
This is a project for SAN provisioning. It has three components:
1) driver
2) API
3) UI

The driver component is a set of script to be invoked locally on the host
The API layer enable remote invocation of the driver script over http using curl commands
The UI layer renders a SAN provisioning user interface using the API layer

The API layer can be started with the command:
python3 manage.py runserver ipaddress:port
and is written using django for a REST interface

The API layer can drive the SAN provisioning by passing commands like:
curl -i -k 'http://<ipaddress>:<port>/san/v1/exports' -X POST -d <parameters>

API and UI layer code sample are already provided.

