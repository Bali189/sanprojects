
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var fs = require("fs");
var crypto = require('crypto');
var flash = require('express-flash');
//var tls = require('tls');
var https = require('https');
var http = require("http");
var path = require('path');
var querystring = require('querystring');
var Hogan = require("hogan.js");
/*
var winston = require("winston");
//var jquery = require("jquery");
//var jqueryterminal = require("jquery.terminal");
winston.add(winston.transports.File, {filename:'containers.log'});
winston.level='debug';
*/
var ini = require('ini');
var config = ini.parse(fs.readFileSync('./config.ini', 'utf-8'));
//console.log('config=%o',config);
var login_url = config.global.login; 

var app = express();

//var https_options = {
//    key: fs.readFileSync('privkey.pem'),
//    cert: fs.readFileSync('cacert.pem')
//};

// all environments

app.set('host', process.env.HOST || process.env.VCAP_APP_HOST || config["global"]["localhost"]); //'10.51.16.155'); // The port on the DEA for communication with the application: 
app.set('port', process.env.PORT || process.env.VCAP_APP_PORT || config["global"]["localport"]); //'8778'); // Start server app.listen(port, host);
//app.set('port', process.env.PORT || 443);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hjs');
//app.set('key', fs.readFileSync('privkey.pem'));
//app.set('cert', fs.readFileSync('cacert.pem'));
app.use(flash());
app.use(express.favicon());
//app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
/* This method causes conflict on Diego CF */
//app.use(express.methodOverride());
/* due to requirements of express */
//app.use(express.session({ secret: 'your secret here' }));
app.use(express.cookieParser());
app.use(express.session({secret: '1234567890QWERTY'}));
app.use(app.router);
app.use(require('less-middleware')({ src: path.join(__dirname, 'public') }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('public/images', express.static(path.join(__dirname, 'public/images')));
app.use('public/javascripts', express.static(path.join(__dirname, 'public/javascripts')));
app.use('public/stylesheets', express.static(path.join(__dirname, 'public/stylesheets')));
app.use(require('connect-flash')());
  // Expose the flash function to the view layer
app.use(function(req, res, next) {
    res.locals.flash = function() { return req.flash() };
    res.locals.flash = req.flash.bind(req);
    next();
  })

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.use(express.logger('dev'));
var winston = require("winston");
winston.add(winston.transports.File, {filename:'containers.log'});
winston.level='debug';
/*
//app.get('/', routes.index);
require('./saml/saml')(app);
function secure(req,res,next){
      winston.log('debug', req.url);
      winston.log('debug', 'inside secure:'+req.toString());
//res.redirect(login_url); return;
      // Check session
      if(req.session.currentUser){
        next();
      }else{
        winston.log('debug', 'startAuth called');
        //next();
        app.settings.saml.startAuth(req, res);
      }
    }
app.all('/', secure);
app.use(function(req, res, next) {
  winston.log('debug','URL='+req.url);
  winston.log('debug','URL='+req.url);
   if(req.url.substr(-1) != '/')
       if (req.url.indexOf('?') > -1)
          res.redirect(301, req.url.replace('?','/?'));
       else
          res.redirect(301, req.url+'/');
   else if(req.url.length == 1)
       res.redirect(301, '/containerslist/');
   else
       secure(req, res, next);
});
//var serveroptions={
//'host': app.get('host'),
//'port': app.get('port'),
//}
*/
var server = http.createServer(app).listen(app.get('port'), app.get('host'), function(){
  winston.log('debug', 'APP='+app.get('host'));
  winston.log('debug','PORT='+app.get('port'));
  //winston.log('debug','Express server listening on port ' + app.get('port'));
});

var clusters = [];
var servers = []; //[{"name":"sj100005177231.corp.adobe.com"}];

app.get('/containerslist/', function (req, res){
  //winston.log('debug', 'containerslist requested');
/*
  if(!req.session.currentUser){
 // req.flash('error', 'User is not signed in yet.'); 
   winston.log('debug', 'User is not signed in yet at containerslist.');
res.redirect(login_url); return;}
*/
  var servers = {};
  var i = 0;
  var email = (req.session.currentUser) ? req.session.currentUser.email : "";
  //winston.log('debug','EMAIL='+email);
  //winston.log('debug', 'EMAIL='+email);
  if (!email){
     res.redirect(login_url);return;}
  //winston.log('debug','EMAIL2='+email);
  var options = {
    host: config.linuxhost.server,
    port: parseInt(config.linuxhost.port),
    path: '/lxd/v1/containers',
    method: 'get',
    headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Authorization': 'Basic '+ config.itcapi.auth,
    'X-Ldap': email.split('@')[0],
    }
  };
  var httpreq = http.request(options, function (response) {
    response.setEncoding('utf8');
    clustersJson = ''
    response.on('data', function (chunk) {
      res.setHeader('Content-Type', 'application/json');
      clustersJson += chunk;
    });
    response.on('end', function() {
      try{
      clusters = JSON.parse(clustersJson)["containers"];
      //winston.log('debug','JSON=' + clustersJson); //.substring(0,100));
      //winston.log('debug','clusters=%o', clusters);
      if (clusters && clusters.length > 0){
      clusters.sort(function(a, b){
             if(a.CREATED < b.CREATED) return 1;
             if(a.CREATED > b.CREATED) return -1;
             return 0;
      });
      }
      //winston.log('debug','clusters=%o',clusters);
      res.setHeader('Content-Type', 'text/html');

      res.render('listcluster', {'clusters':clusters, 'message':req.flash('error')}, function(err, html) {
      if ( html ){
      var h = html;
      //winston.log('debug','LEN='+h.length);
      insertion = "";
      data = "";
//<option value=\"detail\">Detail Cluster</option>
      if (clustersJson != "{}"){
       //       NAME      |  STATE  |        IPV4         |                     IPV6                      |    TYPE    | SNAPSHOTS
      }else{
         data='<p>You have no containers yet.</p>';
      }
      // winston.log('debug','LEN3');
      h = html.replace('LIST_OF_CLUSTERS', data);
      if(req.session.currentUser){
         h = h.replace('EMAIL_OF_USER', req.session.currentUser.email.split('@')[0]);
      }else{
        //app.settings.saml.startAuth(req, res);
         h = h.replace('EMAIL_OF_USER','rajamani'); //// app_local
      }
      h  = h.replace('{{ title }}', 'List of Containers');
      h = h.replace('CLUSTERS_JSON', JSON.stringify(clusters));
      res.setHeader('Content-Type', 'text/html');
          //winston.log('debug', 'sending success for containerslist');
          res.send(h);
      }
      });
      }catch(e){
       res.send('Service is unavailable.');
      }
    });
  });
  httpreq.end();
});

app.get('/containeradd/', function(req, res){
/*
     if(!req.session.currentUser){
res.redirect(login_url); return;}
*/
  var email = (req.session.currentUser) ? req.session.currentUser.email : "";
     cluster = {};
     res.render('addcluster', cluster, function(err, html) {
      var h = html;
      if(req.session.currentUser){
         h = html.replace('EMAIL_OF_USER', req.session.currentUser.email.split('@')[0]);
      }else{
         h = h.replace('EMAIL_OF_USER','rajamani'); //// app_local
      }
      var template = Hogan.compile(h);
      h = template.render({'cluster':cluster});
        res.setHeader('Content-Type', 'text/html');
         winston.log('debug', 'containeradd success');
        res.send(h);
     });
});

app.post('/containeradd/', function(req, res){
/*
      if(!req.session.currentUser){
   winston.log('debug', 'User is not signed in yet at containeradd post.');
res.redirect(login_url); return;}
*/
           cluster = {};
           cluster.name = req.body.name;
  if (!email){
     res.redirect(login_url);return;}
   var regexp = /^[a-zA-Z0-9_-]+$/;
        if (!cluster.name || cluster.name.search(regexp) == -1)
        {
            var message = "Only alphabets, underscore and hyphen allowed in cluster name.";
            req.flash('error',message);
            winston.log('debug', 'FLASH='+message);
            res.redirect('/containerslist/');
                return ;
        }
  var post_data = 'name='+cluster.name;
  winston.log('debug','params='+post_data);
  var options = {
    host: config.linuxhost.server,
    port: parseInt(config.linuxhost.port),
    path: '/lxd/v1/containers',
    method: 'POST',
    headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Content-Length': post_data.length,
    'Authorization': 'Basic '+ config.itcapi.auth,
    'X-Ldap': email.split('@')[0],
      }
  };
  message = '';
  winston.log('debug', 'container_add_options: url='+options["host"]+":"+options["port"].toString()+options["path"]);
  var httpreq = http.request(options, function (response) {
    response.setEncoding('utf8');
    providersJson = '';
    response.on('data', function (chunk) {
      providersJson += chunk;
      winston.log('debug', "%o", providersJson);
    });
    response.on('end', function() {
      try{
      winston.log('containeradd_returned=%o',providersJson);
      providers = JSON.parse(providersJson);
      winston.log('debug','providers=' + providersJson.substring(0,200));
            message = providers['msg'];
            req.flash('error',message);
            winston.log('debug', 'FLASH='+message);
            res.send(JSON.stringify(providers));
                return ;
      }catch(e){
       console.log(e);
       winston.log('debug', "%o", e);
            message = providers['msg'];
            req.flash('error',message);
            winston.log('debug', 'FLASH='+message);
            res.send(JSON.stringify(providers));
                return ;
      }
      });
    });
  if (post_data && post_data != ''){
      winston.log('debug', 'writing post_data='+post_data);
      httpreq.write(post_data);
  }
});
